package kg.gov.mtsdr.ubk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UbkApplicationTests {

	@Test
	void contextLoads() {
	}

}
